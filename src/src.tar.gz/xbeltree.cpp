/*****************************************************************************
 **
 ** Copyright (C) 2013 Digia Plc and/or its subsidiary(-ies).
 ** Contact: http://www.qt-project.org/legal
 **
 ** This file is part of the examples of the Qt Toolkit.
 **
 ** $QT_BEGIN_LICENSE:BSD$
 ** You may use this file under the terms of the BSD license as follows:
 **
 ** Redistribution and use in source and binary forms, with or without
 ** modification, are permitted provided that the following conditions are
 ** met:
 **   * Redistributions of source code must retain the above copyright
 **     notice, this list of conditions and the following disclaimer.
 **   * Redistributions in binary form must reproduce the above copyright
 **     notice, this list of conditions and the following disclaimer in
 **     the documentation and/or other materials provided with the
 **     distribution.
 **   * Neither the name of Digia Plc and its Subsidiary(-ies) nor the names
 **     of its contributors may be used to endorse or promote products derived
 **     from this software without specific prior written permission.
 **
 **
 ** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 ** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 ** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 ** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 ** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 ** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 ** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 ** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 ** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 ** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 ** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
 **
 ** $QT_END_LICENSE$
 **
 ****************************************************************************/

#include <QtWidgets>

#include "xbeltree.h"

XbelTree::XbelTree(QWidget *parent)
  : QTreeWidget(parent)
{
  QStringList labels;
  labels << tr("Title") << tr("Location") << tr("Weight") << tr("Score");
  //labels << tr("Title")  << tr("Weight") << tr("Score");

  //  header()->setSectionResizeMode(QHeaderView::Stretch);
    header()->setSectionResizeMode(QHeaderView::ResizeToContents);
  setHeaderLabels(labels);

  folderIcon.addPixmap(style()->standardPixmap(QStyle::SP_DirClosedIcon),
		       QIcon::Normal, QIcon::Off);
  folderIcon.addPixmap(style()->standardPixmap(QStyle::SP_DirOpenIcon),
		       QIcon::Normal, QIcon::On);
  bookmarkIcon.addPixmap(style()->standardPixmap(QStyle::SP_FileIcon));
}

bool XbelTree::read(QIODevice *device)
{
  QString errorStr;
  int errorLine;
  int errorColumn;

  if (!domDocument.setContent(device, true, &errorStr, &errorLine,
			      &errorColumn)) {
    QMessageBox::information(window(), tr("DOM Bookmarks"),
			     tr("Parse error at line %1, column %2:\n%3")
			     .arg(errorLine)
			     .arg(errorColumn)
			     .arg(errorStr));
    return false;
  }

  QDomElement root = domDocument.documentElement();
  if (root.tagName() != "xbel") {
    QMessageBox::information(window(), tr("DOM Bookmarks"),
			     tr("The file is not an XBEL file."));
    return false;
  } else if (root.hasAttribute("version")
	     && root.attribute("version") != "1.0") {
    QMessageBox::information(window(), tr("DOM Bookmarks"),
			     tr("The file is not an XBEL version 1.0 "
				"file."));
    return false;
  }

  clear();

  disconnect(this, SIGNAL(itemChanged(QTreeWidgetItem*,int)),
	     this, SLOT(updateDomElement(QTreeWidgetItem*,int)));

  QDomElement child = root.firstChildElement("folder");
  while (!child.isNull()) {
    parseFolderElement(child);
    child = child.nextSiblingElement("folder");
  }

  connect(this, SIGNAL(itemChanged(QTreeWidgetItem*,int)),
	  this, SLOT(updateDomElement(QTreeWidgetItem*,int)));

  return true;
}


bool XbelTree::refresh() {
  QDomElement root = domDocument.documentElement();
  
  clear();
  
  disconnect(this, SIGNAL(itemChanged(QTreeWidgetItem*,int)),
	     this, SLOT(updateDomElement(QTreeWidgetItem*,int)));

  QDomElement child = root.firstChildElement("folder");
  while (!child.isNull()) {
    parseFolderElement(child);
    child = child.nextSiblingElement("folder");
  }

  connect(this, SIGNAL(itemChanged(QTreeWidgetItem*,int)),
	  this, SLOT(updateDomElement(QTreeWidgetItem*,int)));

  return true;
}



bool XbelTree::write(QIODevice *device)
{
  const int IndentSize = 4;

  QTextStream out(device);
  domDocument.save(out, IndentSize);
  return true;
}
double XbelTree::getWeighSum (QDomElement item) {
  QDomElement child = item.firstChildElement();
  double sum=0.0;

  while (!child.isNull()) {
    if (child.hasAttribute("weight")) {
      sum+=child.attribute("weight").toDouble();
    }
    child = child.nextSiblingElement();
  }
  printf("%lf",sum);
  if (sum > 0.001 ) {
    return sum;
  }
  return 0;
}
void XbelTree::updateDomWeight(QDomElement item) {
  double sum=getWeighSum(item);
  QDomElement child = item.firstChildElement();

  while (!child.isNull() ) {
    if (child.tagName()!="folder"  && child.tagName()!="bookmark") {
      child = child.nextSiblingElement();
      continue;
    }
    if (child.tagName()=="folder") {
      updateDomWeight(child);
    }
    if (child.hasAttribute("weight")) {
      printf("-\n%lf\n-",child.attribute("weight").toDouble()/sum);
      child.setAttribute("weight",QString::number(child.attribute("weight").toDouble()/sum));
    }
    child = child.nextSiblingElement();
  }
  
  //refresh();
}
double XbelTree::getWeight(QDomElement item) {
  if (item.tagName() !="bookmark" && item.tagName()!="folder") {
    return 0;
  }
  if (!item.hasAttribute("weight")) {
    return 0;
  }
  return item.attribute("weight").toDouble();
}


double XbelTree::getScore(QDomElement item) {
  double score=0;
  if (item.tagName() ==  "bookmark") {
    if (item.hasAttribute("score")) {
      printf("book,%lf\n",item.attribute("score").toDouble());
      return item.attribute("score").toDouble();
    }
    return 0;
  }
  QDomElement child = item.firstChildElement();
  QTreeWidgetItem* titem=new QTreeWidgetItem;
  while (!child.isNull()) {
    score+=getScore(child)*getWeight(child);
    child = child.nextSiblingElement();
  }
  
  
  
  item.setAttribute("score",QString::number(score));
  refresh();
  return score;
}

  
  

void XbelTree::updateDomElement(QTreeWidgetItem *item, int column)
{

  QDomElement element = domElementForItem.value(item);
  if (!element.isNull()) {
    if (column == 0) {

      QDomElement oldTitleElement = element.firstChildElement("title");
      QDomElement newTitleElement = domDocument.createElement("title");

      QDomText newTitleText = domDocument.createTextNode(item->text(0));
      newTitleElement.appendChild(newTitleText);

      element.replaceChild(newTitleElement, oldTitleElement);
      
    } else {
      if (element.tagName() == "bookmark")
	element.setAttribute("href", item->text(1));
    }
    element.setAttribute("weight", item->text(2));
    element.setAttribute("score", item->text(3));

  }
  
  QDomElement root = domDocument.documentElement();
  QDomElement child = root.firstChildElement("folder");
  // child.setAttribute("weight","123");

   // updateDomWeight(root);
  
  // printf("%s",child.firstChildElement().tagName());
  // getWeighSum(child);
  printf("%lf\n",getScore(root));

}


void XbelTree::updateDomWeightAll() {
  QDomElement root = domDocument.documentElement();
  updateDomWeight(root);
  refresh();
  
}


void XbelTree::parseFolderElement(const QDomElement &element,
                                  QTreeWidgetItem *parentItem)
{
  QTreeWidgetItem *item = createItem(element, parentItem);

  QString title = element.firstChildElement("title").text();
  if (title.isEmpty())
    title = QObject::tr("Folder");

  item->setFlags(item->flags() | Qt::ItemIsEditable);
  item->setIcon(0, folderIcon);
  item->setText(0, title);
  item->setText(2, element.attribute("weight"));
  item->setText(3, element.attribute("score"));

  item->setFlags(item->flags() & ~(Qt::ItemIsSelectable|Qt::ItemIsEditable));

  bool folded = (element.attribute("folded") != "no");
  // setItemExpanded(item, !folded);

  setItemExpanded(item, true);
  
    
  QDomElement child = element.firstChildElement();
  while (!child.isNull()) {
    if (child.tagName() == "folder") {
      parseFolderElement(child, item);



    } else if (child.tagName() == "bookmark") {
      QTreeWidgetItem *childItem = createItem(child, item);

      QString title = child.firstChildElement("title").text();
      if (title.isEmpty())
	title = QObject::tr("Folder");

      childItem->setFlags(item->flags() | Qt::ItemIsEditable);
      childItem->setIcon(0, bookmarkIcon);
      childItem->setText(0, title);
      childItem->setText(1, child.attribute("href"));
      childItem->setText(2, child.attribute("weight"));
      childItem->setText(3, child.attribute("score"));

	    
    } else if (child.tagName() == "separator") {
      QTreeWidgetItem *childItem = createItem(child, item);
      childItem->setFlags(item->flags() & ~(Qt::ItemIsSelectable | Qt::ItemIsEditable));
      childItem->setText(0, QString(30, 0xB7));
	
    }
    child = child.nextSiblingElement();
  }
}

QTreeWidgetItem *XbelTree::createItem(const QDomElement &element,
                                      QTreeWidgetItem *parentItem)
{
  QTreeWidgetItem *item;
  if (parentItem) {
    item = new QTreeWidgetItem(parentItem);
  } else {
    item = new QTreeWidgetItem(this);
  }
  domElementForItem.insert(item, element);
  return item;
}
